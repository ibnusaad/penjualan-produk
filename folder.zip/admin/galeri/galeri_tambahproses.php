<?php
$nama_gambar = $_FILES['gambar']['name'];
$lokasi_gambar = $_FILES['gambar']['tmp_name'];
$tipe_gambar = $_FILES['gambar']['type'];

$tanggal	= date('Ymd');

if ($lokasi_gambar==""){
	mysql_query("INSERT INTO galeri SET 
judul = '$_POST[judul]',
tanggal = '$tanggal'
		") or die (mysql_error());
} else {
	move_uploaded_file($lokasi_gambar,
		"../gambar/galeri/$nama_gambar");
	mysql_query("INSERT INTO galeri SET 
judul = '$_POST[judul]',
tanggal = '$tanggal',
gambar = '$nama_gambar'
		") or die (mysql_error());
}
echo "Data telah tersimpan";
echo "<meta http-equiv='refresh'
content='1; url=?tampil=galeri'>";
?>