<?php
mail($_POST['email'], $_POST['subjek'], $_POST['pesan'],
	"from: pemilik.website@gmail.com");

echo "Pesan telah dibalas";
echo "<meta http-equiv='refresh'
content='1; url=?tampil=pesan'>";
?>