<div class="container">
            <?php
            $artikel = mysql_query("select * from artikel order by id_artikel");
    while($data = mysql_fetch_array($artikel)){
        $isi = substr($data['isi'],0,400);
        $isi = substr($data['isi'],0,strrpos($isi," "));
    ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="fh5co-blog animate-box">
                        <?php if($data['gambar']!="") ?><a href="#" class="blog-bg" style="background-image: url(gambar/artikel/<?php echo $data['gambar']; ?>"></a>
                        <div class="blog-text">
                            <span class="posted_on">Feb. 15th 2016</span>
                            <h3><a href="#"><?php echo $data['judul']; ?></a></h3>
                            <p><?php echo $isi; ?> ... </p>
                            <ul class="stuff">
                               
                                <li><a href="?tampil=artikel_detail&id=<?php echo $data['id_artikel']; ?>">Read More<i class="icon-arrow-right22"></i></a></li>
                            </ul>
                        </div> 
                    </div>
                </div>
<?php
}
?></div>
</div>
</div>

    <div id="fh5co-slider">
        <div class="container">
            <div class="row">
                <div class="col-md-6 animate-box">
                    <div class="heading">
                        <h2>Download Our Latest Free HTML5 Bootstrap Template</h2>
                        <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
                    </div>
                </div>
                <div class="col-md-6 col-md-push-1 animate-box">
                    <aside id="fh5co-hero">
                    <div class="flexslider">
                        <ul class="slides">
                        <li style="background-image: url(images/rpd.jpg);">
                            <div class="overlay-gradient"></div>
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12 col-md-offset-0 col-md-pull-10 slider-text slider-text-bg">
                                        <div class="slider-text-inner">
                                            <div class="desc">
                                                    <h2>Air Free HTML5 Bootstrap Template</h2>
                                                    <p>Ink is a free html5 bootstrap and a multi-purpose template perfect for any type of websites. A combination of a minimal and modern design template. The features are big slider on homepage, smooth animation, product listing and many more</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li style="background-image: url(images/penyiar.jpeg);">
                            <div class="overlay-gradient"></div>
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12 col-md-offset-0 col-md-pull-10 slider-text slider-text-bg">
                                        <div class="slider-text-inner">
                                            <div class="desc">
                                                    <h2>Ink Free HTML5 Bootstrap Template</h2>
                                                    <p>Ink is a free html5 bootstrap and a multi-purpose template perfect for any type of websites. A combination of a minimal and modern design template. The features are big slider on homepage, smooth animation, product listing and many more</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li style="background-image: url(images/header.png);">
                            <div class="overlay-gradient"></div>
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-md-12 col-md-offset-0 col-md-pull-10 slider-text slider-text-bg">
                                        <div class="slider-text-inner">
                                            <div class="desc">
                                                    <h2>Travel Free HTML5 Bootstrap Template</h2>
                                                    <p>Ink is a free html5 bootstrap and a multi-purpose template perfect for any type of websites. A combination of a minimal and modern design template. The features are big slider on homepage, smooth animation, product listing and many more</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>           
                        </ul>
                    </div>
                </aside>
                </div>
            </div>
        </div>
    </div>

    
               
    <div id="fh5co-started">
        <div class="overlay"></div>
        <div class="container">
            <div class="row animate-box">
                <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                    <h2>Hire Us!</h2>
                    <p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
                    <p><a href="#" class="btn btn-default btn-lg">Contact Us</a></p>
                </div>
            </div>
        </div>
    </div>