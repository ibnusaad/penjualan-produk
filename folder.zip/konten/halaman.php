<?php
if(!defined("INDEX")) die ("---");
$artikel = mysql_query("select * from halaman where id_halaman='$_GET[id]'");
$data=mysql_fetch_array($artikel);
$isi = $data['isi'];
?>
<center><div class="halaman">
<h2 class="judul"><?php echo $data['judul']; ?></h2>
<p>
<?php echo $isi; ?>
</p>
</div></center>
 <div id="fh5co-started">
        <div class="overlay"></div>
        <div class="container">
            <div class="row animate-box">
                <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                    <h2>Hire Us!</h2>
                    <p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
                    <p><a href="#" class="btn btn-default btn-lg">Contact Us</a></p>
                </div>
            </div>
        </div>
    </div>

