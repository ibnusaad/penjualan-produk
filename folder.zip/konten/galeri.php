	<link rel="stylesheet" type="text/css" href="plugin/fancybox/jquery.fancybox.css">
	<script type="text/javascript" src="plugin/fancybox/jquery.fancybox.js"></script>
	<script type="text/javascript">
		$(document).ready(function(){
		$('.fancybox').fancybox();
		});
	</script>
<?php
	if(!defined("INDEX")) die("---");
?>
<div id="fh5co-portfolio">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Portfolio</h2>
					<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia.</p>
				</div>
			</div>
	
	<div class="galeri">
		<div class="row">
	
<?php	
	$no = 1;
	$artikel = mysql_query("select * from galeri order by id_galeri desc limit 12");
	while($data=mysql_fetch_array($artikel)){
?>
		<div class="col-md-4">
			<a class="fancybox" href="gambar/galeri/<?php echo $data['gambar']; ?>" title="<?php echo $data['judul']; ?>">
				<img src="gambar/galeri/<?php echo $data['gambar']; ?>" width="100%" class="thumbnail" >
				<p align="center"> <?php echo $data['judul']; ?></p>
			</a>
		</div>
<?php
		if($no%4 == 0) echo"</div><div class='row'>";
		$no++;
	}
?>
</div>
</div>
</div>
 <div id="fh5co-started">
        <div class="overlay"></div>
        <div class="container">
            <div class="row animate-box">
                <div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
                    <h2>Hire Us!</h2>
                    <p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
                    <p><a href="#" class="btn btn-default btn-lg">Contact Us</a></p>
                </div>
            </div>
        </div>
    </div>

